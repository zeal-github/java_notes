package com.itranswarp.learnjava.html;

public class ParagraphBuilder {

	public String buildParagraph(String line) {
		return "<p>" + line + "</p>";
	}
}
