package com.itranswarp.learnjava.html;

public class HrBuilder {

	public String buildHr(String line) {
		return "<hr/>";
	}
}
