package com.itranswarp.learnjava.bridge;

public class HybridEngine implements Engine {

	@Override
	public void start() {
		System.out.println("Start Hybrid Engine...");
	}
}
