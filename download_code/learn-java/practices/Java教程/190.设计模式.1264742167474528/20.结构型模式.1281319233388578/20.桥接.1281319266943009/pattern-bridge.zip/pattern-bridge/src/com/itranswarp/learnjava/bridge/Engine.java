package com.itranswarp.learnjava.bridge;

public interface Engine {

	void start();
}
