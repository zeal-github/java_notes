package com.itranswarp.learnjava;

/**
 * Sum of integers.
 */
public class SumOfInteger {

	public static void main(String[] args) {
		int n = 100;
		// TODO: sum = 1 + 2 + ... + n
		int sum = ?;
		System.out.println(sum);
	}

}
