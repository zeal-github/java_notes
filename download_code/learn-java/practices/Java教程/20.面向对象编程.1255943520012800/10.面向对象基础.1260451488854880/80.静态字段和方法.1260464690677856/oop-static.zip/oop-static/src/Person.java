
public class Person {

	// TODO

	String name;

	public Person(String name) {
		this.name = name;
	}

}
